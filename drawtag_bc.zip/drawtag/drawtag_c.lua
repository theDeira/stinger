function initDrawTag()
	createDrawingWindow()
	initSpraying()
end
addEventHandler("onClientResourceStart",resourceRoot,initDrawTag)

