
Dimension = { ["0"] = true };


local r_Root = getResourceRootElement(  getThisResource()  );

local size = 1.7

local r , g , b , a = 0 , 255 , 0 , 255

local _type = "checkpoint"




local r0 = createMarker( 1417 ,  -3 , 1001 - 1  , _type , size , r,g,b,a  )

local r1 = createMarker( 1418 ,  -47 ,1001 - 1 , _type , size , r,g,b,a )

local r2 = createMarker( 1407 ,  6 ,  1001 - 1 , _type , size , r,g,b,a )

local r3 = createMarker( 1387 , -48 , 1001 - 1 , _type , size , r,g,b,a )




local markers = { r0 , r1 , r2 , r3 };






for m in pairs( markers )do 



setElementDimension( markers[ m ] , 0  )
setElementInterior( markers[ m ] , 1 )

addEventHandler( "onMarkerHit", markers[ m ] , function( _player )
setElementData( _player , "knife.godmode" , "on" );
end)









addEventHandler( "onMarkerLeave", markers[m], function( _player )
setElementData( _player , "knife.godmode" , "off" );
end)



end









function cMarker( dim )


local r0 = createMarker( 1417 ,  -3 , 1001 - 1  , _type , size , r,g,b,a  )

local r1 = createMarker( 1418 ,  -47 ,1001 - 1 , _type , size , r,g,b,a )

local r2 = createMarker( 1407 ,  6 ,  1001 - 1 , _type , size , r,g,b,a )

local r3 = createMarker( 1387 , -48 , 1001 - 1 , _type , size , r,g,b,a )




local markers = { r0 , r1 , r2 , r3 };






for m in pairs( markers )do 



setElementDimension( markers[ m ] , tonumber( dim )  )
setElementInterior( markers[ m ] , 1 )

end


end






--addCommandHandler("dim",function( _player, cmd , dim )

addEventHandler( "onPlayerChangeDimension", getRootElement() , function( dim )


if( (dim and  type( tonumber(dim ) ) == 'number') and tonumber( dim ) >= 0 )then


local num = split( dim , "." )

if( tonumber( num[1] ) <= 60000 )then

if( Dimension[ num[1] ] ~= true )then Dimension[ num[1] ] = true; 
cMarker( num[1] )

end


end

end



end)












addEventHandler("onPlayerJoin",getRootElement(), function( _player )



setElementData(  source , "knife.godmode" , "off"  ); 



end)














