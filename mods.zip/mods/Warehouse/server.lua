addEvent( "giveWe_" , true );
addEvent("destroyVehicle",true)




function getKnife( ped )

local id = 0

if( ped  and isElement( ped ))then



local g = getPedWeaponSlot( ped )

if( g )then





end
end

return id

end






local e_cached = {};


function createData( data )


data = type(data) == 'string' and data or '';

if( type( e_cached[ data ] ) == "table" )then

return e_cached[ data ];

else

e_cached[ data ] = {};

return e_cached[ data ];

end


end





function osay( data , text )

text = type( text ) == "string" and text or ""

local e = true;

local c8 = createData( data );

c8[ #c8 + 1 ] = text; 

if( #c8 >= 5  )then e_cached[ data ] = {}; end

if( c8[ #c8 - 1 ] == text )then

e = false

c8[ #c8 - 1 ] = nil;

table.remove( c8 , #c8-1 );


end

return e

end






function msg( ped , text , color , colorCode ,active )

text = type( text ) == "string" and text or ""
color = type( color ) == "table" and color or {}

local c = color  

c.r = type( c.r ) == "number" and c.r or 0
c.g = type( c.g ) == "number" and c.g or 0
c.b = type( c.b ) == "number" and c.b or 0


colorCode = type( colorCode ) == "boolean" and colorCode or true;


if( (ped and isElement( ped )) and getElementType( ped ) == "player" )then


if( active == true and osay( getPlayerSerial( ped ) , text ) )then
outputChatBox( text , ped , c.r, c.g , c.b , colorCode )
end


end
end







TIME_ID1 = nil

function _startf4(player,text)
text= type(text) == 'string' and text or '';

if( TIME_ID1 == nil and isTimer( TIME_ID1 ) == false )then


TIME_ID1 = setTimer( function(  ) 

if( TIME_ID1 and isTimer( TIME_ID1 ) )then  

killTimer( TIME_ID1 );
TIME_ID1 = nil
osay( getPlayerSerial( player ) , "");

end




end , 20000 , 1 , text);



end
end















function destroyVehicle( ped , b )

if( b and (ped and (isElement(ped) and getElementType( ped ) == "vehicle")) )then 

destroyElement( ped )

end 


if(b == false and isPedInVehicle( ped ) )then


local vehicle = getPedOccupiedVehicle( ped )


if( vehicle )then

destroyElement( vehicle )

end

end
end



addEventHandler("destroyVehicle",getRootElement(),destroyVehicle)


addEventHandler( "giveWe_" , getRootElement() , function( id )

if( (source and isElement( source )) and getElementType( source ) == "player" )then


giveWeapon( source , 4 , 1 ); 


if( id > 0 )then

setPedWeaponSlot( source , id );

end






end
end)











function hitTest( x  , y )

local tX = false 
local tY = false
local hX = 1354
local hX_end = 1422
local hY = 300;
local hY_end = -53 

hX = 800;
hY_end = -1000;
hX_end = 2000;


if( x >= hX and x <= hX_end or  (  x <= hX and x >= hX_end  ))then tX = true;  end

if( (y >= hY and y <= hY_end) or (  y <= hY and y >= hY_end  ) )then tY = true; end


return (tX and tY)

end





function Extra( p )

if( get("Grav") == 'true' )then
setPedGravity( p , tonumber( get("GravDefault") ) );
end

if( get("Speed") == 'true' )then triggerClientEvent("knife.speed",p,tonumber( get("SpeedDefault")  )); end


end







addEventHandler( "onPlayerWasted", getRootElement( ),
    function()
    
    local weapon = getPedWeapon( source )
    local X , Y , Z = getElementPosition( source );
    local int = 1;
    local dim = getElementDimension( source );
    local skin = getElementModel( source );
    local pos = { 
    
    ['1'] = { x = 1417 , y = -3 , z = 1001 } ,
    ['2'] = { x = 1418 , y = -47 , z = 1001 },
    ['3'] = { x = 1407 , y = 6 , z = 1001 },
    ['4'] = { x = 1387 , y = -48 , z = 1001 } 
    
    }
    
    if( (hitTest(X,Y) and ( isPedDead( source ) and get("Spawn") == 'true' )) and  getElementInterior(source)== 1 )then
    
     fadeCamera(  source , false , tonumber( get("FadeCamera") ) )
    
     local pos = pos[ tostring(math.random(1,4))  ]

    
    setTimer(function( p , x , y ,z )
    
        
    spawnPlayer( p , x , y , z , 0 , skin , int , dim )
    Extra( p );
    giveWeapon( p , weapon , 9999 );
    setCameraTarget (p, p)
    
    end, tonumber( get("Interval") ), 1, source, pos.x , pos.y , pos.z )
    
    
    
    
    
    end
    
    
    
    
    
    
    
    
    
    
    
    end
)















function onStealthKill(targetPlayer)
    
   

    local weapon = getPedWeapon( targetPlayer )
    local X , Y , Z = getElementPosition( targetPlayer );
    local int = 1;
    local dim = getElementDimension( targetPlayer );
    local skin = getElementModel( targetPlayer );
    local pos = { 
    
    ['1'] = { x = 1417 , y = -3 , z = 1001 } ,
    ['2'] = { x = 1418 , y = -47 , z = 1001 },
    ['3'] = { x = 1407 , y = 6 , z = 1001 },
    ['4'] = { x = 1387 , y = -48 , z = 1001 } 
    
    }
    
    
    
    
   
    
    
    if( (hitTest(X,Y) and ( isPedDead( targetPlayer ) and get("Spawn") == 'true' )) and getElementInterior(targetPlayer)==1 )then
    
    fadeCamera(  targetPlayer , false ,  tonumber( get("FadeCamera") )  )
    
      local pos = pos[ tostring(math.random(1,4))  ]
    
    
    setTimer(function( p , x , y ,z )
    
    spawnPlayer( p , x , y , z , 0 , skin , int , dim  )
    Extra( p );
    giveWeapon( p , weapon , 9999 );
    setCameraTarget(p , p)
    
    end, tonumber( get("Interval") ) , 1, targetPlayer , pos.x , pos.y , pos.z )
    
    
   
    
    
    end
    
    













end
addEventHandler("onPlayerStealthKill", getRootElement(), onStealthKill)





