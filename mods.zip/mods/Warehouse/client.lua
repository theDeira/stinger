local g_Me = getLocalPlayer();

local r_Root = getResourceRootElement(  getThisResource()  );

local data = {};

data[ g_Me ] = {};













function isKnife( player )

if( (player and isElement(player )) and getPedWeapon( player , getPedWeaponSlot( player ) ) == 4 )then

return true
end

return false

end

 



function isWeapon0( player )

if( (player and isElement(player )) and getPedWeapon( player , getPedWeaponSlot( player ) ) == 0 )then

return true
end

return false

end




local l = guiCreateLabel( 100 , 30 , 300 ,40 , "" , false )
local t = guiCreateLabel( 100 , 60 , 300 ,30 , "" , false )



function hitTest( x  , y )

local tX = false 
local tY = false
local hX = 1354
local hX_end = 1422
local hY = 300;
local hY_end = -53 

hX = 800;
hY_end = -1000;
hX_end = 2000;


if( x >= hX and x <= hX_end or  (  x <= hX and x >= hX_end  ))then tX = true;  end

if( (y >= hY and y <= hY_end) or (  y <= hY and y >= hY_end  ) )then tY = true; end


return (tX and tY)

end






function destroyAll()


local vehicles = getElementsByType( "vehicle" );

for index,vh in ipairs( vehicles ) do

if( vh and isElement( vh ) )then

local vx , vy , vz = getElementPosition( vh );


if( vz >= 900 and hitTest( vx , vy ) )then  

triggerServerEvent("destroyVehicle", g_Me , vh , true );

end



end
end
end



function _antiBug()

if( Rising.isPlayerInWarehouse( g_Me ) )then

else

setElementData( g_Me , "knife.godmode" , "off" );

end
end






  
addEventHandler("onClientPreRender",getRootElement(), function()

 
local x , y , z = getElementPosition( g_Me );
 
--guiSetText( l  , "x: "..x.." y: "..y.." z: "..z   )


local tX = false;  
local tY = false
local hZ = 900




if( z >= hZ )then



if( hitTest( x , y  ) and getElementInterior(g_Me) )then


destroyAll()

triggerServerEvent("destroyVehicle", g_Me , g_Me );

if( isKnife( g_Me ) == false and getElementData(g_Me , "knife.weapon") == "off" )then 

setElementData( g_Me , "knife.getSlotFromWeapon" , getSlotFromWeapon( 4 ) );
triggerServerEvent("giveWe_", g_Me , getSlotFromWeapon( 4 ) );  end

else

setElementData( getLocalPlayer() , "knife.godmode" , "off" )
--outputChatBox("Fuera de Warehouse")


end

else

setElementData( getLocalPlayer() , "knife.godmode" , "off" )
--outputChatBox("Fuera de Warehouse")


end




end)










addEvent("knife.speed",true);

addEventHandler( "knife.speed" , getLocalPlayer() , function()



setGameSpeed(1);




end)







