
local _dim = { };

local g_Me = getLocalPlayer();


addEvent("onClientPlayerChangeDimension",true);




addEventHandler("onClientRender",getRootElement(),function()


local g_Dim = getElementDimension( g_Me ); 




if( #_dim == 0 )then

_dim[ #_dim + 1 ] = g_Dim;

end



if( _dim[ #_dim  ] ~= g_Dim )then 

_dim = { }; 


triggerEvent("onClientPlayerChangeDimension",g_Me,g_Dim);
triggerServerEvent( "onPlayerChangeDimension" , g_Me , g_Dim );

end






end);






addEventHandler( "onClientPlayerChangeDimension", getRootElement() , function()





end);
