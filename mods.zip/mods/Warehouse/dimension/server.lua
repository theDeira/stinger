
local _EVENT_NAME = "onPlayerChangeDimension"


addEvent( _EVENT_NAME , true );









addEventHandler(  _EVENT_NAME , getRootElement() , function( dim ) 








end)