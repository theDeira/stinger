<?xml version="1.0" encoding="utf-8"?>
<resstate>
  <openedFolder>Client</openedFolder>
  <openedFolder>Server</openedFolder>
</resstate>