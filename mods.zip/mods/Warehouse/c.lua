addCommandHandler( "knife",
    function( player )
        setElementInterior( player, 1, 1401.3, -15, 1000.8 ) -- teleport player to the centre of SA
    end
)