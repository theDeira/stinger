
Rising = {

version = "1.0" , 
author = "Slash+>",
libs = {}

};








function hitTest( x  , y )

local tX = false 
local tY = false
local hX = 1354
local hX_end = 1422
local hY = 300;
local hY_end = -53 

hX = 800;
hY_end = -1000;
hX_end = 2000;


if( x >= hX and x <= hX_end or  (  x <= hX and x >= hX_end  ))then tX = true;  end

if( (y >= hY and y <= hY_end) or (  y <= hY and y >= hY_end  ) )then tY = true; end


return (tX and tY)

end













function Rising.getPlayerInWarehouse()

local players = getElementsByType("player");

local ret = {};


for elem,index in ipairs( players )do 

local x , y , z = getElementPosition( players[ elem ] );

if( hitTest(x , y ) and getElementInterior( players[ elem ] ) == 1 )then 


ret[ #ret + 1 ] = elem;


end


end


return ret

end





function isPlayer( player )



if( (player and isElement( player ) ) and getElementType( player ) == 'player' )then

return true

else 

return false

end
end








function Rising.isPlayerInWarehouse( player )

local check = false

if( isPlayer( player ) )then

local players = Rising.getPlayerInWarehouse();



for p,index in ipairs( players )do 

if( getPlayerSerial( p ) == getPlayerSerial( player ) )then

check = true

end


end

end

return check

end






function spairs(t, order)
    -- collect the keys
    local keys = {}
    for k in pairs(t) do keys[#keys+1] = k end

    -- if order function given, sort by it by passing the table and keys a, b,
    -- otherwise just sort the keys 
    if order then
        table.sort(keys, function(a,b) return order(t, a, b) end)
    else
        table.sort(keys)
    end

    -- return the iterator function
    local i = 0
    return function()
        i = i + 1
        if keys[i] then
            return keys[i], t[keys[i]]
        end
    end
end











