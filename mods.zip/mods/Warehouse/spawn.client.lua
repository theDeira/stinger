
addEventHandler ( "onClientPlayerDamage", getRootElement() ,
function ()
    if getElementData(source,"knife.godmode") == 'on'  then
        cancelEvent()
    end
end)
 
addEventHandler("onClientPlayerStealthKill",getLocalPlayer(),
function (targetPlayer)
    if getElementData(targetPlayer,"knife.godmode") == 'on' then
        cancelEvent()
    end
end)









local r_Root = getResourceRootElement(  getThisResource()  );




addEventHandler("onClientResourceStart", r_Root , function()


setElementData( getLocalPlayer() , "knife.weapon" , "off" )
setElementData( getLocalPlayer() , "knife.godmode" , "off" )


end)














