---SCRIPT BY -RoCk-Alex----
---copyright -RoCk- clan

outputChatBox( "#FFFF00===[HELPMANAGER BY -RoCk-ALEX]===",0,255,0,true )
outputChatBox( "#00FF00===[PRESS F9 TO OPEN IT]===",0,255,0,true )
localPlayer = getLocalPlayer()

wnd_window = {}

addEventHandler( "onClientResourceStart", getResourceRootElement( getThisResource() ),  
	function ( theResource )
		--outputConsole( "wnd_showServerInfo called" )
		--outputConsole( " source: ".. tostring( source ) )
		--outputConsole( " resourceStarted: ".. tostring( theResource ) )
		if source == getResourceRootElement( theResource ) then
			--outputConsole( " passed if: source == resource" )
			local cmd = xmlLoadFile( "cmd.xml" )
			local cmd1 = xmlNodeGetValue( cmd )
			local member = xmlLoadFile( "member.xml" )
			local member1 = xmlNodeGetValue( member )
			local other = xmlLoadFile( "other.xml" )
			local other1 = xmlNodeGetValue( other )
			local server = xmlLoadFile( "server.xml" )
			local server1 = xmlNodeGetValue( server )

		    wnd_create( cmd1, member1, other1, server1 )
		end
	end
)
function wnd_create( cmd, member, other, server )

GUIEditor_TabPanel = {}
GUIEditor_Tab = {}
GUIEditor_Memo = {}
GUIEditor_Image = {}

window = guiCreateWindow(336,330,744,546,"-RoCk- Help Manager",false)
guiSetAlpha(window,1)
guiWindowSetSizable(window,false)
background = guiCreateStaticImage(0.0165,0.0549,0.9669,0.9191,"images/background.png",true,window)
guiSetAlpha(background,1)
guiSetProperty(background,"Disabled","true")
GUIEditor_Image[1] = guiCreateStaticImage(0.0081,0.0023,0.0043,0.005,"images/logo.png",true,window)
guiSetAlpha(GUIEditor_Image[1],1)
guiSetProperty(GUIEditor_Image[1],"Disabled","true")
GUIEditor_TabPanel[1] = guiCreateTabPanel(0.0404,0.2457,0.921,0.6936,true,window)
guiSetAlpha(GUIEditor_TabPanel[1],1)
tabcmd = guiCreateTab("-RoCk-basemode Commands",GUIEditor_TabPanel[1])
guiSetAlpha(tabcmd,1)
GUIEditor_Memo[1] = guiCreateMemo(0.008,0.0231,0.984,0.9583,cmd,true,tabcmd)
guiSetAlpha(GUIEditor_Memo[1],1)
GUIEditor_Tab[1] = guiCreateTab("-RoCk Members",GUIEditor_TabPanel[1])
guiSetAlpha(GUIEditor_Tab[1],1)
GUIEditor_Memo[2] = guiCreateMemo(0.01,0.0324,0.98,0.9444,member,true,GUIEditor_Tab[1])
guiSetAlpha(GUIEditor_Memo[2],1)
GUIEditor_Tab[2] = guiCreateTab("-RoCk- news",GUIEditor_TabPanel[1])
guiSetAlpha(GUIEditor_Tab[2],1)
GUIEditor_Memo[3] = guiCreateMemo(0.008,0.0185,0.982,0.963,other,true,GUIEditor_Tab[2])
guiSetAlpha(GUIEditor_Memo[2],1)
GUIEditor_Tab[2] = guiCreateTab("Server Info",GUIEditor_TabPanel[1])
guiSetAlpha(GUIEditor_Tab[2],1)
GUIEditor_Memo[4] = guiCreateMemo(0.008,0.0185,0.982,0.963,server,true,GUIEditor_Tab[2])
guiSetAlpha(GUIEditor_Memo[4],1)
guiMemoSetReadOnly(GUIEditor_Memo[1],true)
guiMemoSetReadOnly(GUIEditor_Memo[2],true)
guiMemoSetReadOnly(GUIEditor_Memo[3],true)
guiMemoSetReadOnly(GUIEditor_Memo[4],true)
end


-- BIND THE TOUCH F9

function onresourceStart ()
  bindKey ("F9", "down", showUserPanel)
  guiSetVisible (window, false)
end
addEventHandler("onClientResourceStart", getResourceRootElement(getThisResource()), onresourceStart)

function showUserPanel ()
getVisible = guiGetVisible (window)
playerName = getPlayerName ( getLocalPlayer() )
if (getVisible == true) then
	guiSetVisible (window, false)
	showCursor (false)
	playSound("open.wav")

end
if (getVisible == false) then
	guiSetVisible (window, true)
	showCursor (true)
	playSound("open.wav")
  	end
end