addEvent("onZombieWasted",true)
addEventHandler("onZombieWasted",getRootElement(),
function (killer)
local m = math.random(200,500)
exports.xloginpanel:GPM(killer,m)
end)