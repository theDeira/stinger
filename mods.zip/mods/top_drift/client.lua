﻿local Key = "F3" --- bind key

HD = {
    gridlist = {},
    S3D = {},
    q = {}
}

function centerWindow(center_window)
    local screenW,screenH=guiGetScreenSize()
    local windowW,windowH=guiGetSize(center_window,false)
    local x,y = (screenW-windowW)/2,(screenH-windowH)/2
    guiSetPosition(center_window,x,y,false)
end

HD.wnd = guiCreateWindow(415, 146, 450, 505, "Top 30 Drift Script || By MR.S3D V1.2", false)
guiWindowSetSizable(HD.wnd, false)
guiSetAlpha(HD.wnd, 1.00)
guiSetProperty(HD.wnd, "CaptionColour", "FF200AF3")
centerWindow(HD.wnd)
HD.gridlist[1] = guiCreateGridList(18, 32, 430, 500, false, HD.wnd)
local column = guiGridListAddColumn(HD.gridlist[1], "Rank", 0.20 ) -- Create a 'rank' column in the list
local column1 = guiGridListAddColumn(HD.gridlist[1], "Player Name", 0.40 ) -- Create a 'players' column in the list
local column2 = guiGridListAddColumn(HD.gridlist[1], "Total Drift", 0.30 ) -- Create a 'Total Drift' column in the list
for i = 1,30 do
local row = guiGridListAddRow ( HD.gridlist[1] )
guiGridListSetItemText ( HD.gridlist[1], row, column, "" .. i .. "-", false, false )
guiGridListSetItemText ( HD.gridlist[1], row, column1, "N/A", false, false )
guiGridListSetItemText ( HD.gridlist[1], row, column2, "N/A", false, false )
guiGridListSetItemColor(HD.gridlist[1], row, column1, 255, 255, 0)
guiGridListSetItemColor(HD.gridlist[1], row, column2, 0, 180, 255)
guiGridListSetItemColor(HD.gridlist[1], row, column, 255, 0, 0)
end
guiSetVisible(HD.wnd, not guiGetVisible(HD.wnd))

bindKey (Key, "down",
	function()
		guiSetVisible(HD.wnd, not guiGetVisible(HD.wnd))
		showCursor(guiGetVisible(HD.wnd))
		triggerServerEvent("getTop", localPlayer)
	end
)

function convertNumber ( number )  
	local formatted = number  
	while true do      
		formatted, k = string.gsub(formatted, "^(-?%d+)(%d%d%d)", '%1,%2')    
		if ( k==0 ) then      
			break   
		end  
	end  
	return formatted
end

function updateTopList(name, top, i)
local row = guiGridListAddRow ( HD.gridlist[1] )
guiGridListSetItemText ( HD.gridlist[1], row, column, "" .. i .. "-", false, false )
guiGridListSetItemText ( HD.gridlist[1], row, column1, tostring(name), false, false )
guiGridListSetItemText ( HD.gridlist[1], row, column2, convertNumber(top), false, false )
guiGridListSetItemColor(HD.gridlist[1], row, column1, 255, 255, 0)
guiGridListSetItemColor(HD.gridlist[1], row, column2, 0, 180, 255)
guiGridListSetItemColor(HD.gridlist[1], row, column, 255, 0, 0)
end
addEvent("updateTop", true)
addEventHandler("updateTop", root, updateTopList)

function update()
guiGridListClear(HD.gridlist[1])
end
addEvent("deltTop", true)
addEventHandler("deltTop", root, update)