drift_mejor = 0
addEventHandler( 'onResourceStart', getResourceRootElement(getThisResource()),
	function( )
		outputChatBox("==[ Top-30 Drift Script | By MR.S3D ]==", root, 255, 125, 0,true)
		outputChatBox("==[ Press F5 To Open Top-30 Top-Drift Script ]==", root, 50, 255, 0,true)
		executeSQLQuery( 'CREATE TABLE IF NOT EXISTS Drift_top_byS3Dd (Owner, Score, Name)' )
	end
)

function getPlayerFromNamePart(name)
    if name then 
        for i, player in ipairs(getElementsByType("player")) do
            if string.find(getPlayerName(player):lower(), tostring(name):lower(), 1, true) then
                return player 
            end
        end
    end
    return false
end

function createTopSystem( player )
	if not isElement( player ) then
		return
	end
	local Top = {}
	local CreatTop = executeSQLQuery( "SELECT * FROM Drift_top_byS3Dd" )
	for i = 1, #CreatTop do
		table.insert(Top,{name = CreatTop[i].Name,score = CreatTop[i].Score})
	end
	if #CreatTop >0 then
		table.sort(Top, function(a,b) return (tonumber(a.score)or 0) > (tonumber(b.score)or 0) end)
	setTimer(
	function()
		for k, data in ipairs(Top) do
			if k == 1 then
				triggerClientEvent (player,"deltTop",player)
			end	
			triggerClientEvent (player,"updateTop",player,tostring(data.name),tostring(data.score),tonumber(k))
			if k == 30 then
					table.remove(Top)
				break
			end
		end
	end,
		500,
	1
	)
	end
end

function setAcontSqlData( player, top, name)
	if not isElement( player ) then
		return
	end
    if isGuestAccount ( getPlayerAccount ( player ) ) then return end
	result = executeSQLQuery("SELECT * FROM `Drift_top_byS3Dd` WHERE `Owner`=?", getAccountName(getPlayerAccount( player )))
	if ( type ( result ) == "table" and #result == 0 ) or not result then
		executeSQLQuery( 'INSERT INTO Drift_top_byS3Dd( Owner, Score , Name) VALUES( ?, ?, ? )', getAccountName(getPlayerAccount( player )), top, name)
	else
		if tonumber ( top ) < tonumber( result[1]["Score"] ) then top = result[1]["Score"] else top = top end
		executeSQLQuery( 'UPDATE Drift_top_byS3Dd SET Score =?,Name =? WHERE Owner =?', top, name, getAccountName(getPlayerAccount( player )))
	end
end

addEvent("driftNuevoRecord", true)
addEventHandler("driftNuevoRecord", root, 
	function(score, name)
		drift_mejor = score
		drift_nombre = getPlayerFromNamePart(name)
		setAcontSqlData( drift_nombre, drift_mejor, name)
	end
)

addEventHandler("onElementDataChange",root,
	function (data)
		if ( data == "Best Drift" ) and getElementType(source) == "player" then
			local drift = getElementData(source,data)
			setAcontSqlData( source, tonumber(drift), string.gsub(getPlayerName(source), "#%x%x%x%x%x%x", ""))
		end			
	end
)

addEvent("getTop", true)
addEventHandler("getTop", root, 
	function()
		createTopSystem( source )
	end
)