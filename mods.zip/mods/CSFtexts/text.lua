
local screenWidth, screenHeight = guiGetScreenSize()
local fontsTable = {{15,"default-bold",1.2},{16,"bankgothic",0.5}}
local dxMessages = {}
local dxMessagesY = {-25, -25, -25, -25 }
local dxMessagesTick = {}
local sx, sy = guiGetScreenSize()
local fontNumber = 1
local isMoving = false
local thecur = false
addEventHandler("onClientResourceStart",getResourceRootElement(getThisResource()),
function ()
	if sx > 1280 then
	fontNumber = 1
	end
	end
)

function drawMessages()
	for index, messageData in pairs(dxMessages) do
		--dxDrawRectangle((screenWidth / 1100) * 250, (screenHeight / 900) * dxMessagesY[index], (screenWidth / 1440) * 760, (screenHeight / 900) * 25, tocolor(0, 0, 0, 180))
		--dxDrawText(messageData[1], (screenWidth / 1100) * 250, (screenHeight / 900) * (dxMessagesY[index] * 2), (screenWidth / 1440) * 1100, (screenHeight / 900) * 25, tocolor(messageData[2], messageData[3], messageData[4], 255), (screenWidth / 850) * 1, "default-bold", "center", "center", false, true, false)
		dxDrawBorderedText(messageData[1],(screenWidth / 1100) * 250,(screenHeight / 900) * (dxMessagesY[index] * 2),(screenWidth / 1440) * 1100,(screenHeight / 900) * 25,tocolor(messageData[2], messageData[3], messageData[4], 255),fontsTable[fontNumber][3],fontsTable[fontNumber][2],"center","center",false,true,false)
	end
end
addEventHandler("onClientRender", root, drawMessages)

function output(message, r, g, b)
if thecur == message then return end
	if dxGetTextWidth(message, (screenWidth / 1440) * 1, "default-bold") > 750 then output("Invalid Length", 255, 0, 0) return end
	r, g, b = r or 255, g or 255, b or 255
	if #dxMessages == 4 or isMoving then setTimer(output, 1000, 1, message, r, g, b) return end
	table.insert(dxMessages, {message, r, g, b})
	dxMessagesTick[#dxMessages] = getTickCount()
	addEventHandler("onClientRender", root, addMessage)
	isMoving = true
	outputConsole(message)
	thecur = message
end
addEvent("CSFtext.output", true)
addEventHandler("CSFtext.output", root, output)

function addMessage()
	local index = #dxMessages
	local difference = (screenHeight / 900) * 1.5
	dxMessagesY[index] = dxMessagesY[index] + difference
	if dxMessagesY[index] >= (index - 1) * 25 then
		dxMessagesY[index] = (index - 1) * 25
		if #dxMessages == 4 then
			isMoving = true
			addEventHandler("onClientRender", root, removeMessage)
			removeEventHandler("onClientRender", root, addMessage)
		else
			isMoving = false
			removeEventHandler("onClientRender", root, addMessage)
		end
	end
end

function removeMessage()
	local difference = (screenHeight / 900) * 1.5
	for index = 1, #dxMessages do
		dxMessagesY[index] = dxMessagesY[index] - difference
	end
	if dxMessagesY[1] <= -25 then
		for index = 1, #dxMessages do
			dxMessages[index] = dxMessages[index + 1]
			dxMessagesTick[index] = dxMessagesTick[index + 1]
			dxMessagesY[index] = (index - 1) * 25
		end
		isMoving = false
		removeEventHandler("onClientRender", root, removeMessage)
		for index = 1, #dxMessagesY do
			if not dxMessages[index] then dxMessagesY[index] = -25 end
		end
	end
end

function removeReadMessages()
	for index, message in pairs(dxMessages) do
		local currentTick = getTickCount()
		if currentTick - dxMessagesTick[index] >= 15000 then
			removeMessage()
		end
	end
end
addEventHandler("onClientRender", root, removeReadMessages)

function dxDrawBorderedText( text, x, y, w, h, color, scale, font, alignX, alignY, clip, wordBreak, postGUI )
	dxDrawText ( text, x - 1, y - 1, w - 1, h - 1, tocolor ( 0, 0, 0, 255 ), scale, font, alignX, alignY, clip, wordBreak, false ) -- black
	dxDrawText ( text, x + 1, y - 1, w + 1, h - 1, tocolor ( 0, 0, 0, 255 ), scale, font, alignX, alignY, clip, wordBreak, false )
	dxDrawText ( text, x - 1, y + 1, w - 1, h + 1, tocolor ( 0, 0, 0, 255 ), scale, font, alignX, alignY, clip, wordBreak, false )
	dxDrawText ( text, x + 1, y + 1, w + 1, h + 1, tocolor ( 0, 0, 0, 255 ), scale, font, alignX, alignY, clip, wordBreak, false )
	dxDrawText ( text, x - 1, y, w - 1, h, tocolor ( 0, 0, 0, 255 ), scale, font, alignX, alignY, clip, wordBreak, false )
	dxDrawText ( text, x + 1, y, w + 1, h, tocolor ( 0, 0, 0, 255 ), scale, font, alignX, alignY, clip, wordBreak, false )
	dxDrawText ( text, x, y - 1, w, h - 1, tocolor ( 0, 0, 0, 255 ), scale, font, alignX, alignY, clip, wordBreak, false )
	dxDrawText ( text, x, y + 1, w, h + 1, tocolor ( 0, 0, 0, 255 ), scale, font, alignX, alignY, clip, wordBreak, false )
	dxDrawText ( text, x, y, w, h, color, scale, font, alignX, alignY, clip, wordBreak, postGUI )
end