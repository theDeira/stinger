-------I got some help from a friend so we made this script Together !                                              -
-------They Say If You search for help You will Got It just Don't Give Up !
-----------Made By Simo_khanich And Anwar_Mohamed


local gateone = createObject(985,288.0450744628906, 1407.360717773438, 11.11663627624512, 0, 0, 270) 
local gatetw = createObject(986,288.0450744628906, 1415.237670898438, 11.11663627624512, 0, 0, 270) 
local corona = createMarker (287.3920288085938, 1412.035766601563, 8.939068794250488, "corona", 9.5, 255, 255, 0, 0 )


function openGate(hitPlayer, matchingDimension)
		 if source then
		moveObject(gateone, 2000, 288.0450744628906, 1399.497802734375, 11.11663627624512)
		moveObject(gatetw, 2000, 288.0450744628906, 1423.064453125, 11.11663627624512)
	end
end


function closeGate( source )
	setTimer(function()
		if not isElementWithinMarker(getRootElement(), corona) then 
			moveObject(gateone, 2000, 288.0450744628906, 1407.360717773438, 11.11663627624512, 0, 0, 0)
			moveObject(gatetw, 2000, 288.0450744628906, 1415.237670898438, 11.11663627624512, 0, 0, 0)
		end
	end, 500,1)
end


addEventHandler( "onMarkerHit", corona, openGate )
addEventHandler( "onMarkerLeave", corona, closeGate )