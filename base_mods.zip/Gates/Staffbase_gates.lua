-------I got some help from a friend so we made this script Together !                                              -
-------They Say If You search for help You will Got It just Don't Give Up !
-----------Made By Simo_khanich And Anwar_Mohamed


local gateone = createObject(985, 2497.311279296875, 2777.093017578125, 11.52335643768311, 0, 0, 90.00003051757813) 
local gatetw = createObject(986, 2497.311279296875, 2769.23291015625, 11.52335643768311, 0, 0, 270+90+90) 
local corona = createMarker ( 2497.73120,2772.80859,10.33875, "corona", 9.5, 255, 255, 0, 0 )


function openGate(hitPlayer, matchingDimension)
		 if source then
		moveObject(gateone, 2000, 2497.311279296875, 2784.93798828125, 11.52335643768311)
		moveObject(gatetw, 2000, 2497.311279296875, 2761.4423828125, 11.52335643768311)
	end
end


function closeGate( source )
	setTimer(function()
		if not isElementWithinMarker(getRootElement(), corona) then 
			moveObject(gateone, 2000, 2497.311279296875, 2777.093017578125, 11.52335643768311, 0, 0, 0)
			moveObject(gatetw, 2000, 2497.311279296875, 2769.23291015625, 11.52335643768311, 0, 0, 0)
		end
	end, 500, 1)
end


addEventHandler( "onMarkerHit", corona, openGate )
addEventHandler( "onMarkerLeave", corona, closeGate )