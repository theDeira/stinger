-------I got some help from a friend so we made this script Together !                                              -
-------They Say If You search for help You will Got It just Don't Give Up !
-----------Made By Simo_khanich And Anwar_Mohamed


local gateone = createObject(10184,  -1631.736083984375, 688.5777587890625, 8.590116500854492, 0, 0, 90) 
local gatetw = createObject(3037,-1620.873657226563, 688.4007568359375, 11.07466697692871, 90, 0, 270) 
local corona = createMarker (-1626.61376953125, 688.4263916015625, 6.190120697021484, "corona", 9.5, 255, 255, 0, 0 )


function openGate(hitPlayer, matchingDimension)
		 if source then
		moveObject(gateone, 2000, -1631.736083984375, 688.5777587890625, 13.330618858337)
		moveObject(gatetw, 2000, -1620.873657226563, 688.4007568359375, 14.27966785430908)
	end
end


function closeGate( source )
	setTimer(function()
		if not isElementWithinMarker(getRootElement(), corona) then 
			moveObject(gateone, 2000, -1631.736083984375, 688.5777587890625, 8.590116500854492, 0, 0, 0)
			moveObject(gatetw, 2000, -1620.873657226563, 688.4007568359375, 11.07466697692871, 0, 0, 0)
		end
	end, 6000,1)
end


addEventHandler( "onMarkerHit", corona, openGate )
addEventHandler( "onMarkerLeave", corona, closeGate )