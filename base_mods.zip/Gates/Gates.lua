-------I got some help from a friend so we made this script Together !                                              -
-------They Say If You search for help You will Got It just Don't Give Up !
-----------Made By Simo_khanich And Anwar_Mohamed


local gateone = createObject(16773,2539.333251953125, 2827.522705078125, 12.61086559295654, 0, 0, 90) 
local gatetw = createObject(16773,2616.163818359375, 2834.729248046875, 12.72031211853027, 0, 0, 90) 
local corona = createMarker ( 2535.97021,2822.60425,10.82031, "corona", 9.5, 255, 255, 0, 0 )
local corona1 = createMarker ( 2617.57007,2830.65137,10.82031, "corona", 9.5, 255, 255, 0, 0 )


function openGate(hitPlayer, matchingDimension)
	 if source then
		moveObject(gateone, 2000, 2539.333251953125, 2833.5908203125, 12.61086559295654)
		moveObject(gatetw, 2000,2616.163818359375, 2841.208984375, 12.72031211853027)
	end
end


function closeGate( source )
	setTimer(function()
		if not isElementWithinMarker(getRootElement(), corona) then 
			moveObject(gateone, 2000, 2539.333251953125, 2827.522705078125, 12.61086559295654, 0, 0, 0)
			moveObject(gatetw, 2000, 2616.163818359375, 2834.729248046875, 12.72031211853027, 0, 0, 0)
		end
	end, 500, 1)
end


addEventHandler( "onMarkerHit", corona, openGate )
addEventHandler( "onMarkerLeave", corona, closeGate )