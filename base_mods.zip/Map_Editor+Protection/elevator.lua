local Elevator = createObject(3095,  2630.51171875, 2699.54736328125, 13.72929859161377, 0, 0)        
function floor1()                                               
moveObject(Elevator, 4000,  2630.51171875, 2699.54736328125, 13.72929859161377, 0, 0, 0) --ground floor
end
addCommandHandler("1", floor1)
function floor2()
moveObject(Elevator, 4000,  2629.82421875, 2699.9047851563, 119.74839782715, 0, 0, 0) -- 2nd floor
end
addCommandHandler("2", floor2)
function floor3()
moveObject(Elevator, 4000,  2631.3962402344, 2698.1560058594, 49.880676269531, 0, 0, 0) -- 3rd floor
end
addCommandHandler("3", floor3)
function floor4()                                               
moveObject(Elevator, 4000, 2629.82421875, 2699.9047851563, 219.74839782715, 0, 0, 0) -- 4th floor
end
addCommandHandler("4", floor4)
function floor5()
moveObject(Elevator, 4000,  2629.82421875, 2699.9047851563, 2219.7482910156, 0, 0, 0) -- 5th floor
end
addCommandHandler("5", floor5)
function floor6()
moveObject(Elevator, 4000,  2629.82421875, 2699.9047851563, 3219.7482910156, 0, 0, 0) -- 6th floor
end
addCommandHandler("6", floor6)
function floor7()
moveObject(Elevator, 4000,  2629.82421875, 2699.9047851563, 4219.7485351563, 0, 0, 0) -- 7th floor
end
addCommandHandler("7", floor7)
function floor8()
moveObject(Elevator, 4000,   2629.82421875, 2699.9047851563, 5219.7485351563, 0, 0, 0) -- 8th floor
end
addCommandHandler("8", floor8)
function floor9()
moveObject(Elevator, 4000, 2629.82421875, 2699.9047851563, 6219.7485351563, 0, 0, 0) -- 9th floor
end
addCommandHandler("9", floor9)
function floor10()
moveObject(Elevator, 4000,  2629.82421875, 2699.9047851563, 7219.7485351563, 0, 0, 0) -- 10th floor
end
addCommandHandler("10", floor10)
function floor11()
moveObject(Elevator, 4000,  2629.82421875, 2699.9047851563, 8219.7490234375, 0, 0, 0) -- roof floor
end
addCommandHandler("11", floor11)
