safecol = createColCuboid ( 2499.03198,2675.57837,10.82031, 255,255, 255 )
safeZoneRadar = createRadarArea (  2499.03198,2675.57837,10.82031, 255, 255, 255, 255, 255 )
setElementData (safecol, "zombieProof", true)

function enterZone(hitPlayer, matchingDimension)
  setTimer(function()
  if hasObjectPermissionTo(hitPlayer, "function.kickPlayer") then
    toggleControl (hitPlayer, "fire", true )
    toggleControl (hitPlayer, "aim_weapon", true)
    toggleControl (hitPlayer, "vehicle_fire", true)
  else
   killPed (hitPlayer)
		 	outputChatBox("You have been killed for entering a staff area without permission!", hitPlayer, 250, 40, 100)
end
 end, 1000, 1)
end

addEventHandler( "onColShapeHit", safecol, enterZone )
addEventHandler( "onZoneRadar", safeZoneRadar, enterZone )