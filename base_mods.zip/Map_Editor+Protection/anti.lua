addEventHandler("onResourceStart",resourceRoot,
function() 
safecol = createMarker(-1977.58899,885.52405,45.20313,"cylinder",66,255,0,0,0)
setElementData (safecol, "zombieProof", true)
 setRadarAreaFlashing ( safeZoneRadar, true )
 end
 )

addEventHandler("onMarkerLeave", root,
function(player)
    if (source == safecol) then
        if getElementType(player) == "player" then
            toggleControl(player, "fire", true)
            toggleControl(player, "aim_weapon", true)
            toggleControl(player, "vehicle_fire", true)
        end
    end
end)
 
 
addEventHandler("onMarkerHit", root,
function(player)
    if (source == safecol) then
        if getElementType(player) == "player" then
            toggleControl(player, "fire", false)
            toggleControl(player, "aim_weapon", false)
            toggleControl(player, "vehicle_fire", false)
        elseif getElementType(player) == "ped" and getElementData(player, "zombie") then
            killPed(player)
        end
    end
end)
 
 