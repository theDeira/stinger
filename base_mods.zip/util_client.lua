---------------------------------------------------------------------------
-- variables
---------------------------------------------------------------------------
local anything = false
local collisions = {}
local models = {}

local _engineImportTXD = engineImportTXD
local _engineReplaceModel = engineReplaceModel
local _engineRestoreModel = engineRestoreModel
local _engineReplaceCOL = engineReplaceCOL
local _engineRestoreCOL = engineRestoreCOL

addEventHandler('onClientResourceStop', resourceRoot,
	function()
		if not anything then
			return
		end
		
		for model in pairs (models) do
			engineRestoreModel(model)
		end
		for model in pairs (collisions) do
			engineRestoreCOL(model)
		end

		outputDebugString('['..getResourceName(resource)..'] Restored models and collisions')
	end
)

---------------------------------------------------------------------------
-- functions
---------------------------------------------------------------------------
function engineImportTXD(texturepointer, model)
	anything = true
	models[model] = true
	return _engineImportTXD(texturepointer, model)
end

function engineReplaceModel(modelpointer, model, world)
	anything = true
	models[model] = true
	if world == true then
		for i=0,255 do
			removeWorldModel(model, 100000, 0, 0, 0, i)
		end
	end
	return _engineReplaceModel(modelpointer, model)
end

function engineRestoreModel(model)
	models[model] = nil
	if not (#models > 0) and not (#collisions > 0) then
		anything = false
	end
	restoreWorldModel(model, 10000, 0, 0, 0)
	return _engineRestoreModel(model)
end

function engineReplaceCOL(colpointer, model)
	anything = true
	collisions[model] = true
	return _engineReplaceCOL(colpointer, model)
end

function engineRestoreCOL(model)
	collisions[model] = nil
	if not (#models > 0) and not (#collisions > 0) then
		anything = false
	end
	return _engineRestoreCOL(model)
end