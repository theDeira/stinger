---------------------------------------------------------------------------------
--   Hey Man Or Good poeple                                                   - -
--   Please have a good Time with this lol                                    - -
--   Say Thx to Enmity(My Lover) and John_flower  You can visit Them at John Flower's Freeroam Boreedom - -
--   Simple mods By SimoKhanich                                               - -
--   Just search about things cuz there is alot of Great things               - -
---------------------------------------------------------------------------------
addEventHandler("onClientResourceStart", resourceRoot,
	function()
		triggerEvent('addEngineResource', root, getResourceName(resource))
		loadModels()
	end
)
function loadModels()

	local newbed_txd = engineLoadTXD("files/misc/des_ranch.txd")
	engineImportTXD(newbed_txd, 14446)
	
	local vegas_carpark_txd = engineLoadTXD('files/misc/vegas_carpark.txd')
	engineImportTXD(vegas_carpark_txd, 7095)
	local vegas_carpark_dff = engineLoadDFF('files/misc/vegas_carpark.dff', 7095)
	engineReplaceModel(vegas_carpark_dff, 7095)
	local vegas_carpark_col = engineLoadCOL('files/misc/vegas_carpark.col')
	engineReplaceCOL(vegas_carpark_col, 7095)
	local ranch_col = engineLoadCOL("files/misc/des_ranch.col")
	engineReplaceCOL(ranch_col, 11490)
	local ranch_dff = engineLoadDFF("files/misc/des_ranch.dff", 11490)
	engineReplaceModel(ranch_dff, 11490)
	local ranch_rooms_txd = engineLoadTXD("files/misc/des_ranch.txd")
	engineImportTXD(ranch_rooms_txd, 7238)
	local ranch_rooms_col = engineLoadCOL("files/misc/des_ranch_rooms.col")
	engineReplaceCOL(ranch_rooms_col, 7238)
	local ranch_rooms_dff = engineLoadDFF("files/misc/des_ranch_rooms.dff", 7238)
	engineReplaceModel(ranch_rooms_dff, 7238, true)
	local ranch_addons_txd = engineLoadTXD("files/misc/des_ranch.txd")
	engineImportTXD(ranch_addons_txd, 7236)
	local ranch_addons_col = engineLoadCOL("files/misc/des_ranch_addon.col")
	engineReplaceCOL(ranch_addons_col, 7236)
	local ranch_addons_dff = engineLoadDFF("files/misc/des_ranch_addon.dff", 7236)
	engineReplaceModel(ranch_addons_dff, 7236, true)
end