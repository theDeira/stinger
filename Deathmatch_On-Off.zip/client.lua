GUIEditor = { 
    checkbox = {}, 
    staticimage = {}, 
    label = {}, 
    button = {}, 
    window = {} 
} 
addEventHandler("onClientResourceStart", resourceRoot, 
    function() 
        GUIEditor.window[1] = guiCreateWindow(542, 254, 348, 92, "No Deathmatch Mode", false) 
        guiWindowSetSizable(GUIEditor.window[1], false) 
        GUIEditor.label[1] = guiCreateLabel(10, 25, 283, 15, "You can enable or disable 'No Deathmatch' mode.", false, GUIEditor.window[1]) 
        GUIEditor.staticimage[1] = guiCreateStaticImage(10, 50, 34, 26, "icon.png", false, GUIEditor.window[1]) 
        GUIEditor.checkbox[1] = guiCreateCheckBox(49, 52, 234, 24, "Enable / Disable No Deathmatch Mode", false, false, GUIEditor.window[1]) 
        guiSetFont(GUIEditor.checkbox[1], "default-bold-small") 
        GUIEditor.button[1] = guiCreateButton(303, 52, 31, 25, "X", false, GUIEditor.window[1])     
        guiSetVisible(GUIEditor.window[1], false) 
        addEventHandler("onClientGUIClick", GUIEditor.button[1], onGuiClick,false) 
        addEventHandler("onClientGUIClick",GUIEditor.checkbox[1], checkBox, false) 
    end 
) 

  function announceCommands(nick,ip,username,serial,version)
    bindKey(getPlayerFromName(nick),"F1","down","nodm","")
end
addEventHandler("onPlayerJoin",getRootElement(),announceCommands)

  
addCommandHandler("nodm", 
function() 
guiSetVisible(GUIEditor.window[1], true) 
showCursor(true) 
end 
) 
  
function onGuiClick() 
guiSetVisible(GUIEditor.window[1], false) 
showCursor(false) 
end 
  
  
function checkBox() 
        if ( guiCheckBoxGetSelected(GUIEditor.checkbox[1])) then 
        setElementData(localPlayer, "invincible", true) 
        else 
        setElementData(localPlayer, "invincible", false) 
    end 
end 
  
  
addEventHandler ( "onClientPlayerDamage",localPlayer, 
    function () 
        if getElementData(source,"invincible") then 
            cancelEvent() 
        end 
end) 