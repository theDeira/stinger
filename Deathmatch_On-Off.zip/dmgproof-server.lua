--Made By Chris!i!
-- /nodm1 to enable damage proof for your vehicle
-- /nodm2 to disable damage proof for your vehicle
--Enjoy :)
function damageProof (source)
local r,g,b = getPlayerNametagColor ( source ) 
local car = getPedOccupiedVehicle(source)
if car then 
setVehicleDamageProof(car, true)
outputChatBox("Damage Proof Enabled for your vehicle, /nodm2 to disable it!", source, 47, 255, 22)

else

outputChatBox("You have to be in car to do that !", source,22, 174, 255)

end
end
addCommandHandler("nodm1", damageProof) 

function removeProof (source)
local r2,g2,b2 = getPlayerNametagColor ( source )
local car2 = getPedOccupiedVehicle(source)
if car2 then
setVehicleDamageProof (car2, false)
outputChatBox("Damage Proof removed from your vehicle", source, 218, 247, 166)
else
outputChatBox("You have to be in car to do that!", source, 22, 174, 255)
  end
end
addCommandHandler("nodm2", removeProof)
