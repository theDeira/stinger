
function disableWeaponOnGodMod (prev,new) 
    if getElementData(localPlayer, "invincible") then 
            setPedWeaponSlot(localPlayer, 0) 
    end 
end 
addEventHandler ( "onClientRender", root, disableWeaponOnGodMod )