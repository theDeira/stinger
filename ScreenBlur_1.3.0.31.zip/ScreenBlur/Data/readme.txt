Latest customizations:

1. You can use your own Lock sound.
 Replace the LockSound.wav file in Data\Sounds with another one. Keep the name.

2. You can use your own system tray icon.
 Place an icon file (size 16x16) named TrayIcon.ico in the Data folder.
 ScreenBlur won't colorize this icon, and always use it as is.

3. You can edit the timings in the "Auto unlock after" menu that is available
 if you click the button in the upper left corner on the primary screen (or right click anywhere)
 in the first 5 seconds after you lock the screen "on demand",
 and which allows you to set the screen to unlock automatically after a while,
 if you edit the AutoUnlock.txt file in Data\Settings folder. Save it in Unicode format.
 The numbers found there are minutes, which will turn to options in the menu.