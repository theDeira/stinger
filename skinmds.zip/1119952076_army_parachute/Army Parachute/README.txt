***************************
/     Army Parachute      /
/                         /
/     by                  /
/        tomek091         /
/                         /
/                         /
/=========================/


=====About======
 
San Andreas Parachute in Olive Green Color.


=====Install====

Open gta3.img  with IMG Tool 2.0  replace your paracx.txd & gun_para.txd
with these two in zip.




