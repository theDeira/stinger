GTA 5 Online Skin Female Mail
------------------------------------------------------------------------------------------------
GTA 5 Online Mail Female Skin for GTA San Andreas. 

Replaces Sbfyst (id 69). 

Features: 
- Good quality model 
- Good quality textures 
- Movable skeleton 
- Moving hands 
- No egregious bugs 

Free download mod GTA 5 Online Mail Female Skin for GTA San Andreas with automatic installation using the links below.

################################################################################################

AUTHORS
------------------------------------------------------------------------------------------------
Converter AngelAbelGTA

################################################################################################

INSTALLATION INSTRUCTIONS
------------------------------------------------------------------------------------------------
1. Import files in the IMG archive
You can download IMG Manager 2.0 here: http://www.gtaall.com/gta-san-andreas/programs/37425-img-manager-20.html
Crazy IMG Editor here : http://www.gtaall.com/gta-san-andreas/programs/3884-gta-sa-crazy-img-editor.html

Use IMG Manager 2.0 or Crazy IMG Editor to import files from the folder "01 - Import to gta3.img" to archive [GAME FOLDER]\models\gta3.img:
sbfyst.dff
sbfyst.txd

################################################################################################

This modification has been downloaded from www.gtaall.com

Permanent link to modification`s page: https://www.gtaall.com/gta-san-andreas/skins/87881-gta-5-online-skin-female-mail.html

Check out our social groups!
http://vk.com/gtaallcom
https://twitter.com/gtaallcom
http://www.facebook.com/gtaallcom
http://www.youtube.com/gtaallcom