GTA 5 Online Skin Female Mail
------------------------------------------------------------------------------------------------
GTA 5 Online Skin Female Mail для GTA San Andreas.

Заменяет Sbfyst (id 69).

Особенности:
- Модель хорошего качества
- Хорошее качество текстур
- Подвижный скелет
- Подвижные кисти рук
- Нет вопиющих багов

Скачать бесплатно мод GTA 5 Online Skin Female Mail для GTA San Andreas с автоматической установкой можно по ссылкам, расположенным ниже.

################################################################################################

АВТОРЫ
------------------------------------------------------------------------------------------------
Конвертер AngelAbelGTA

################################################################################################

ИНСТРУКЦИИ ПО УСТАНОВКЕ
------------------------------------------------------------------------------------------------
1. Импорт файлов в IMG архив
IMG Manager 2.0 Вы можете скачать тут: http://www.gtavicecity.ru/gta-san-andreas/programs/37425-img-manager-20.html
Crazy IMG Editor тут: http://www.gtavicecity.ru/gta-san-andreas/programs/3884-gta-sa-crazy-img-editor.html

С помощью программы IMG Manager 2.0 или Crazy IMG Editor импортируйте следующие файлы из папки "01 - Import to gta3.img" в архив [Папка с игрой]\models\gta3.img:
sbfyst.dff
sbfyst.txd

################################################################################################

Эта модификация была скачана с сайта www.gtavicecity.ru

Постоянная ссылка на страницу модификации: https://www.gtavicecity.ru/gta-san-andreas/skins/87881-gta-5-online-skin-female-mail.html

Присоединяйтесь к нам в социальных сетях!
http://vk.com/gtavicecityru
https://twitter.com/gtavicecityru
http://www.facebook.com/gtavicecityru
http://www.youtube.com/gtavicecityru