Happy Victory Day everyone! Here's a good quality Red Army shashka for you all. May the glorious victory of Red Army be remembered throughout the generations.

HOW TO USE(for IMGtool):
Replace katana.dff & katana.txd with the ones in archive.

Do anything you want but link to marnutgembul.blogspot.com if you want to reupload.